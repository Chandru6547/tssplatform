const Submission = require("../models/Submission");
const Question = require("../models/Question");
const { executeCode } = require("../services/judge.service");

async function runCodeController(req, res) {
  const { language, code, testcases, questionId } = req.body;

  if (!language || !code) {
    return res.status(400).json({
      error: "language and code are required"
    });
  }

  try {
    let finalTestcases = testcases;
    let isSubmission = false;

    // 🔒 SUBMIT MODE (hidden testcases)
    if (questionId) {
      const question = await Question.findById(questionId);

      if (!question) {
        return res.status(404).json({ error: "Question not found" });
      }

      finalTestcases = question.hiddenTestcases;
      isSubmission = true;
    }

    // 🧪 RUN MODE (sample testcases)
    if (!Array.isArray(finalTestcases)) {
      return res.status(400).json({
        error: "testcases[] required for run"
      });
    }

    const result = await executeCode(language, code, finalTestcases);

    console.log(result);
    

    // 💾 Save only SUBMISSIONS
    let submission = null;
    if (isSubmission) {
      submission = await Submission.create({
        language,
        code,
        question: questionId,
        verdict: result.verdict,
        passed: result.passed,
        results: result.results,
        total: result.total
      });
    }



    res.json({
      submissionId: submission?._id,
      ...result
    });

  } catch (err) {
    res.status(500).json({
      verdict: err.type || "ERROR",
      error: err.message
    });
  }
}

module.exports = { runCodeController };
