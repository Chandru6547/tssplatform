const Question = require("../models/Question");

// CREATE QUESTION
exports.createQuestion = async (req, res) => {
  try {
    const question = await Question.create(req.body);
    res.status(201).json(question);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// GET ALL QUESTIONS (LIST)
exports.getAllQuestions = async (req, res) => {
  const questions = await Question.find({}, "title difficulty");
  res.json(questions);
};

// GET SINGLE QUESTION (HIDE HIDDEN TESTCASES)
exports.getQuestionById = async (req, res) => {
  const question = await Question.findById(req.params.id).select(
    "-hiddenTestcases"
  );
  res.json(question);
};
