const mongoose = require("mongoose");

const TestcaseSchema = new mongoose.Schema({
  input: { type: String, required: true },
  output: { type: String, required: true }
});

const QuestionSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    description: { type: String, required: true },

    sampleTestcases: [TestcaseSchema],
    hiddenTestcases: [TestcaseSchema],

    difficulty: {
      type: String,
      enum: ["Easy", "Medium", "Hard"],
      default: "Easy"
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model("Question", QuestionSchema);
