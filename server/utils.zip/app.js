const express = require("express");
const cors = require("cors");
const connectDB = require("./db");
const { runCodeController } = require("./controllers/judge.controller");
const questionController = require("./controllers/question.controller");
const app = express();
app.use(express.json());
app.use(cors());

connectDB();

app.post("/run", runCodeController);
app.post("/questions", questionController.createQuestion);
app.get("/questions", questionController.getAllQuestions);
app.get("/questions/:id", questionController.getQuestionById);

app.listen(3000, () => {
  console.log("🚀 Judge API running at http://localhost:3000");
});
